import{a as t}from"../chunks/entry.D2ppQcU8.js";export{t as start};
