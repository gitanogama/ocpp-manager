import{a as t}from"../chunks/entry.BwBCSt2f.js";export{t as start};
