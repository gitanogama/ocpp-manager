import{a as t}from"../chunks/entry.BQKQ0BDK.js";export{t as start};
