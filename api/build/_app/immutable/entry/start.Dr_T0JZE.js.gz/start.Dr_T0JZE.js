import{a as t}from"../chunks/entry.fCgy_E2Z.js";export{t as start};
