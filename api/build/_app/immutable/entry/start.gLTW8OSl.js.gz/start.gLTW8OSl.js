import{a as t}from"../chunks/entry.Dv_UzzeL.js";export{t as start};
