import{a as t}from"../chunks/entry.DRH47qL6.js";export{t as start};
