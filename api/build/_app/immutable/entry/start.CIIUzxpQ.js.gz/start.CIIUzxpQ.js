import{a as t}from"../chunks/entry.BO7_q9AM.js";export{t as start};
