import{a as t}from"../chunks/entry.DrIt1gTX.js";export{t as start};
