import{a as t}from"../chunks/entry.Dqgg3Cya.js";export{t as start};
