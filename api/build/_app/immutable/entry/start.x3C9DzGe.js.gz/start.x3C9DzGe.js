import{a as t}from"../chunks/entry.CKdE5lRC.js";export{t as start};
