import{a8 as a}from"./runtime.BhkHmGnc.js";a();
