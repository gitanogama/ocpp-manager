import{a7 as a}from"./runtime.ehUlzqf7.js";a();
