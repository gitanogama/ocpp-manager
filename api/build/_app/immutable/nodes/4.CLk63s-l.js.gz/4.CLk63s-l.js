import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.DAvIKmow.js";import{B as t}from"../chunks/BasePage.B5Pal405.js";function a(o){t(o,{title:"Invoices"})}export{a as component};
