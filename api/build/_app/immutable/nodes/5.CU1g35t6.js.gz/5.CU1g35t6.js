import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.K_zCUCQM.js";import{B as t}from"../chunks/BasePage.BtoTIJcp.js";function a(o){t(o,{title:"Invoices"})}export{a as component};
