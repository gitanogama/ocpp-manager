import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.CjaeNba4.js";import{B as t}from"../chunks/BasePage.BdjcuQGV.js";function a(o){t(o,{title:"Invoices"})}export{a as component};
