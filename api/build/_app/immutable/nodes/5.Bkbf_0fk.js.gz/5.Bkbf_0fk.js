import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.Bk2kbUbt.js";import{B as t}from"../chunks/BasePage.B17YfXTR.js";function a(o){t(o,{title:"Invoices"})}export{a as component};
