import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.DAvIKmow.js";import{B as t}from"../chunks/BasePage.B5Pal405.js";function p(o){t(o,{title:"Monitoring"})}export{p as component};
