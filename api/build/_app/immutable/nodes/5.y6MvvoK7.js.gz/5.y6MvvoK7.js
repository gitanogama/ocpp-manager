import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.Bx86S8IA.js";import{B as t}from"../chunks/BasePage.C0WGob7w.js";function a(o){t(o,{title:"Invoices"})}export{a as component};
