import"../chunks/disclose-version.Bg9kRutz.js";import"../chunks/legacy.C6sR7C_X.js";import{B as t}from"../chunks/BasePage.ByRLVPhr.js";function a(o){t(o,{title:"Invoices"})}export{a as component};
